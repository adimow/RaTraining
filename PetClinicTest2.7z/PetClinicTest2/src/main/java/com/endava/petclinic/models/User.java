package com.endava.petclinic.models;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class User {

    private boolean enabled;
    private String name;
    private String username;
    private String password;
    private List<Role> roles;

    public User() {
    }

    public User(String username, String password, String... roles) {
        this.enabled = true;
        this.username = username;
        this.password = password;
        this.roles = new ArrayList<>();
        for (String roleName:roles) {
            Role role = new Role(roleName);
            this.roles.add(role);
        }
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public List<Role> getRoles() {
        return roles;
    }

    public void setRoles(List<Role> roles) {
        this.roles = roles;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return enabled == user.enabled && Objects.equals(name, user.name) && Objects.equals(username, user.username) && Objects.equals(password, user.password) && Objects.equals(roles, user.roles);
    }

    @Override
    public int hashCode() {
        return Objects.hash(enabled, name, username, password, roles);
    }

    @Override
    public String toString() {
        return "User{" +
                "enabled=" + enabled +
                ", name='" + name + '\'' +
                ", userName='" + username + '\'' +
                ", password='" + password + '\'' +
                ", roles=" + roles +
                '}';
    }
}
