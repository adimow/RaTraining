package com.endava.petclinic;

import com.endava.petclinic.controllers.OwnerController;
import com.endava.petclinic.models.Owner;
import com.endava.petclinic.models.User;
import com.endava.petclinic.utils.EnvReader;
import com.github.javafaker.Faker;
import io.restassured.http.ContentType;
import io.restassured.response.ValidatableResponse;
import org.apache.http.HttpStatus;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;

public class TwitterPostTest {

    @Test
    public void createTwitterTest() {

        given().baseUri(EnvReader.getBaseUriTwitter())
                .basePath(EnvReader.getBasePathTwitter())
                .contentType(ContentType.JSON)
                .auth()
                .oauth(EnvReader.getApiKey(), EnvReader.getApiKeySecret(), EnvReader.getAccessToken(), EnvReader.getAccessTokenSecret())
                .queryParam("status","ADI.MOW2")
                .header("Content-Type", "application/json")
                .when().log().all()
                .post("https://api.twitter.com/1.1/statuses/update.json").prettyPeek()
                .then()
                .statusCode(HttpStatus.SC_OK);
    }


    @Test
    public void getTwitterTest() {

        given().baseUri(EnvReader.getBaseUriTwitter())
                .basePath(EnvReader.getBasePathTwitter())
                .contentType(ContentType.JSON)
                .auth()
                .oauth(EnvReader.getApiKey(), EnvReader.getApiKeySecret(), EnvReader.getAccessToken(), EnvReader.getAccessTokenSecret())
                .queryParam("id","1554856394855178241")
                .when().log().all()
                .get("https://api.twitter.com/1.1/statuses/user_timeline.json").prettyPeek()
                .then()
                .statusCode(HttpStatus.SC_OK);
    }

}