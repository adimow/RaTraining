package com.endava.petclinic;

public class PetClinicTest {
}
