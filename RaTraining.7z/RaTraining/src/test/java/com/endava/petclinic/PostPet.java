package com.endava.petclinic;

import io.restassured.http.ContentType;
import io.restassured.response.ValidatableResponse;
import org.apache.http.HttpStatus;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.is;

public class PostPet {
    @Test
    public void postPetTest(){
        ValidatableResponse response1 =  given().baseUri("http://api.petclinic.mywire.org/")
                .basePath("/petclinic")
                .port(80)
                .contentType(ContentType.JSON)
                .body("{\n" +
                        "  \"birthDate\": \"2011/06/01\",\n" +
                        "  \"id\": null,\n" +
                        "  \"name\": \"Misha\",\n" +
                        "  \"owner\": {\n" +
                        "    \"address\": \"Poienii\",\n" +
                        "    \"city\": \"Craiova\",\n" +
                        "    \"firstName\": \"Adrian\",\n" +
                        "    \"id\": 109,\n" +
                        "    \"lastName\": \"Stanciu\",\n" +
                        "    \"pets\": [\n" +
                        "      null\n" +
                        "    ],\n" +
                        "    \"telephone\": \"0766676963\"\n" +
                        "  },\n" +
                        "  \"type\": {\n" +
                        "    \"id\": 2,\n" +
                        "    \"name\": \"dog\"\n" +
                        "  },\n" +
                        "  \"visits\": [\n" +
                        "    {\n" +
                        "      \"date\": \"yyyy/MM/dd\",\n" +
                        "      \"description\": \"string\",\n" +
                        "      \"id\": 0\n" +
                        "    }\n" +
                        "  ]\n" +
                        "}")
                .when().log().all()
                .post("/api/pets").prettyPeek()
                .then()
                .statusCode(HttpStatus.SC_CREATED);

        Integer petId = response1.extract().jsonPath().getInt("id");
        given().baseUri("http://api.petclinic.mywire.org/")
                .basePath("/petclinic")
                .port(80)
                .pathParam("petId", petId)
                .when()
                .get("/api/pets/{petId}").prettyPeek()
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("id", is(petId));

    }
}
