package com.endava.petclinic;

import io.restassured.http.ContentType;
import io.restassured.response.ValidatableResponse;
import org.apache.http.HttpStatus;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.is;

public class CreateVisit {


    @Test
    public void postVisitTest(){
    ValidatableResponse response2 =  given().baseUri("http://api.petclinic.mywire.org/")
            .basePath("/petclinic")
            .port(80)
            .contentType(ContentType.JSON)
            .body("{\n" +
                    "  \"birthDate\": \"2022/08/01\",\n" +
                    "  \"description\": \"Vizita medicala anuala\",\n" +
                    "  \"id\": null,\n" +
                    "  \"birthDate\": \"2011/06/01\",\n" +
                    "  \"id\": 160,\n" +
                    "  \"name\": \"Misha\",\n" +
                    "  \"owner\": {\n" +
                    "    \"address\": \"Poienii\",\n" +
                    "    \"city\": \"Craiova\",\n" +
                    "    \"firstName\": \"Adrian\",\n" +
                    "    \"id\": 109,\n" +
                    "    \"lastName\": \"Stanciu\",\n" +
                    "    \"pets\": [\n" +
                    "      null\n" +
                    "    ],\n" +
                    "    \"telephone\": \"0766676963\"\n" +
                    "  },\n" +
                    "  \"type\": {\n" +
                    "    \"id\": 2,\n" +
                    "    \"name\": \"dog\"\n" +
                    "  }")
            .when().log().all()
            .post("/api/visits").prettyPeek()
            .then()
            .statusCode(HttpStatus.SC_CREATED);


        Integer visitId = response2.extract().jsonPath().getInt("id");
        given().baseUri("http://api.petclinic.mywire.org/")
                .basePath("/petclinic")
                .port(80)
                .pathParam("visitId", visitId)
                .when()
                .get("/api/owners/{visitId}").prettyPeek()
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("id", is(visitId));

}
}

